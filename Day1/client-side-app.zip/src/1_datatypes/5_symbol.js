// var result = 10 * "abc";
// console.log(result);

// T && T = T
// T && F = F
// F && T = F

// console.log(true && "abc");
// console.log(false && "abc");

// console.log(true ? "abc" : "xyz");
// console.log(false ? "abc" : "xyz");

// console.log(true && "abc" || "xyz");
// console.log(false && "abc" || "xyz");

// if (1) {
//     console.log("Test");
// }

// console.log(Boolean(0));
// console.log(Boolean(1));
// console.log(Boolean(-1));
// console.log(Boolean(""));
// console.log(Boolean("abc"));
// console.log(Boolean(null));
// console.log(Boolean(undefined));

// var obj = null;
// var obj = undefined;
// var obj = { id: 1 };

// if ((obj == null) || (obj == undefined)) {
//     console.log("object is null or undefined");
// } else {
//     console.log("object is:", obj);
// }

// if (!obj) {
//     console.log("object is null or undefined");
// } else {
//     console.log("object is:", obj);
// }

// ---------------------------------------------------------

// let a = 10;
// let b = "10";

// console.log(typeof a);
// console.log(typeof b);

// console.log(a == b);        // Abtract Equality
// console.log(a === b);        // Strict Equality

// let a = { id: 0 };
// let b = { id: 0 };
// let c = b;

// console.log(a == b);        // Abtract Equality
// console.log(a === b);        // Strict Equality

// console.log(b == c);        // Abtract Equality
// console.log(b === c);        // Strict Equality

// -----------------------------------------------------------

// const color = "red";

// // This function should give true only if, color constant is passed in the function
// function isRedColor(str) {
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor("red");

// var clr = "red";
// isRedColor(clr);

// --------------------------

// const color = { c: "red" };

// // This function should give true only if, color constant is passed in the function
// function isRedColor(str) {
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor({ c: "red" });

// var clr = { c: "red" };
// isRedColor(clr);

// --------------------------------------------------------- Symbol (Unique Immutables)

const color = Symbol("red");

// This function should give true only if, color constant is passed in the function
function isRedColor(str) {
    console.log(str === color);
}

isRedColor(color);
isRedColor(Symbol("red"));

var clr = Symbol("red");
isRedColor(clr);


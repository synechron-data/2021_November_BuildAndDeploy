// import 'bootstrap/scss/bootstrap.scss';
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';
// import RootComponent from './components/root/RootComponent';

// import configureStore from './store/configureStore';
// import * as counterActions from './actions/counterActions';

// ReactDOM.render(
//   <React.StrictMode>
//     <RootComponent />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// // const appStore = configureStore();
// // console.log(appStore);
// // console.log(appStore.getState());

// // const appStore = configureStore({counterReducer: 100});
// // console.log(appStore);
// // console.log(appStore.getState());

// const appStore = configureStore();

// appStore.subscribe(() => {
//   console.log("Store State Changed");
//   console.log("New State is: ", appStore.getState());
// });

// // This code will go inside Component
// // Actions
// let incAction = counterActions.incCounter();
// let decAction = counterActions.decCounter();

// appStore.dispatch(incAction);
// appStore.dispatch(incAction);

// appStore.dispatch(decAction);
// appStore.dispatch(decAction);

// --------------------------------------------------------------

import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';
import { Provider } from 'react-redux';

import RootComponent from './components/root/RootComponent';

import configureStore from './store/configureStore';

const appStore = configureStore();
// const appStore = configureStore({ counterReducer: 100 });

ReactDOM.render(
  <React.StrictMode>
    <Provider store={appStore}>
      <RootComponent />
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);
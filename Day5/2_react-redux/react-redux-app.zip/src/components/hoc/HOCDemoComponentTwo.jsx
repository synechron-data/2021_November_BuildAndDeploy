import React, { Component } from 'react';
import ClockHoc from './ClockHoc';
import DataHoc from './DataHoc';

class HOCDemoComponentTwo extends Component {
    render() {
        return (
            <div>
                <h1 className="text-info">Higher Order Component Demo Two</h1>
                <h2 className="text-success">
                    Some Data, added by HOC: {this.props.data}
                </h2>
            </div>
        );
    }
}

export default ClockHoc(DataHoc(HOCDemoComponentTwo));
import React, { Component } from 'react';
import ClockHoc from './ClockHoc';
import DataHoc from './DataHoc';
import ErrorHandlerHoc from './ErrorHandlerHoc';

class HOCDemoComponentOne extends Component {
    render() {
        // throw new Error("Just for Test");
        return (
            <div>
                <h1 className="text-info">Higher Order Component Demo One</h1>
                <h2 className="text-success">
                    Some Data, added by HOC: {this.props.data}
                </h2>
            </div>
        );
    }
}

// export default HOCDemoComponentOne;

// const EnhancedComponent = DataHoc(HOCDemoComponentOne);
// export default EnhancedComponent;

export default ErrorHandlerHoc(ClockHoc(DataHoc(HOCDemoComponentOne)));
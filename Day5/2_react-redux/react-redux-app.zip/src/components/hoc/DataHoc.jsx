import { Component } from "react";

// const DataHoc = function (InputComponent) {
//     return class extends Component {
//         componentDidMount() {
//             this.setState({ data: "Data from DataHoc" });
//         }

//         render() {
//             return <InputComponent {...this.state} {...this.props} />
//         }
//     }
// }

// const DataHoc = (InputComponent) => {
//     return class extends Component {
//         componentDidMount() {
//             this.setState({ data: "Data from DataHoc" });
//         }

//         render() {
//             return <InputComponent {...this.state} {...this.props} />
//         }
//     }
// }

const DataHoc = (InputComponent) => class extends Component {
    static get displayName() {
        return "DataHoc";
    }

    componentDidMount() {
        this.setState({ data: "Data from DataHoc" });
    }

    render() {
        return <InputComponent {...this.state} {...this.props} />
    }
}

export default DataHoc;
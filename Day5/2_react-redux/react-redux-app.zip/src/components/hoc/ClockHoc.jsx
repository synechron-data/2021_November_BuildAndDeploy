import { Component } from "react";

const ClockHoc = (InputComponent) => class extends Component {
    static get displayName() {
        return "ClockHoc";
    }

    constructor(props) {
        super(props);
        this.state = { currentTime: new Date().toLocaleTimeString() };
    }

    componentDidMount() {
        setInterval(() => {
            this.setState({ currentTime: new Date().toLocaleTimeString() });
        }, 1000);
    }

    render() {
        return (
            <>
                <div className="led text-right font-weight-bold text-primary">
                    {this.state.currentTime}
                </div>
                <InputComponent {...this.props} />
            </>
        );
    }
}

export default ClockHoc;
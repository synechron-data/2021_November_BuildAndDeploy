var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

function filter(dataArr, x) {
    // var result = [];

    // for (const name of dataArr) {
    //     // if (name[0] === x) {
    //     //     result.push(name);
    //     // }

    //     // if (name.charAt(0) === x) {
    //     //     result.push(name);
    //     // }

    //     // var testString = `^${x}`;
    //     // if (name.match(testString)) {
    //     //     result.push(name);
    //     // }

    //     if (name.startsWith(x)) {
    //         result.push(name);
    //     }
    // }

    // return result;

    return dataArr.filter(name => name.startsWith(x));
}

var result1 = filter(employees, 'A');
console.log(result1);                   // ["Akshay"];

var result2 = filter(employees, 'B');
console.log(result2);                   // ["Basavaraj", "Bhavya", "Bibhu"];

var result3 = filter(employees, 'C');
console.log(result3);                   // ["Chethan", "Chhavi"];

console.log(employees);                 // ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];
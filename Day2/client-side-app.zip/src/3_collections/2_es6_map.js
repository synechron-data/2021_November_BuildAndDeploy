// Dictionary (Key and Value)

var myMap = new Map();

// console.log(myMap);
// console.log(typeof myMap);
// console.log(myMap.size);

const o = {};

myMap.set('the string', 'This is the value for the string key');
myMap.set(o, 'This is the value for the object key');

// console.log(myMap);
// console.log(myMap.size);

// console.log(myMap.get('the string'));
// console.log(myMap.get(o));

// for (const pair of myMap) {
//     console.log(pair);
// }

// for (const [key, value] of myMap) {
//     console.log(`${key}             ${value}`);
// }

// for (const key of myMap.keys()) {
//     console.log(`${key}`);
// }

// for (const value of myMap.values()) {
//     console.log(`${value}`);
// }

var phoneDirectory = [
    { name: "Manish", phone: 123456 },
    { name: "Abhijeet", phone: 654321 },
];

const contacts = new Map();
contacts.set("Manish", 123456);
contacts.set("Abhijeet", 654321);

console.log(contacts);

contacts.set("Abhijeet", 555555);
console.log(contacts);

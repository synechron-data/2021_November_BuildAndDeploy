// var mySet = new Set();

// // console.log(mySet);
// // console.log(typeof mySet);
// // console.log(mySet.size);

// mySet.add(1);
// mySet.add(2);
// mySet.add(3);
// mySet.add(4);
// mySet.add(5);
// mySet.add(6);

// console.log(mySet);
// console.log(mySet.size);

// mySet.add(1);
// mySet.add(2);
// mySet.add(3);
// mySet.add(4);
// mySet.add(7);
// mySet.add(8);

// console.log(mySet);
// console.log(mySet.size);

var arr = [10, 20, 30, 40, 50, 30, 40, 50, 11, 60, 70, 99];

var unique = Array.from(new Set(arr));
console.log(unique);
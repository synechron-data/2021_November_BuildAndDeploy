let promise = new Promise((resolve, reject) => {
    // Async Code
    setTimeout(function () {
        // resolve(10);
        reject("Some Error");
    }, 5000);
});

// promise.then((data) => {
//     console.log("Success: ", data);
// }, (err) => {
//     console.error("Error: ", err);
// });

// promise.then((data) => {
//     console.log("Success: ", data);
// }).catch((err) => {
//     console.error("Error: ", err);
// });

promise.then((data) => {
    console.log("Success: ", data);
}).catch((err) => {
    console.error("Error: ", err);
}).finally(() => {
    console.log("Finally always run's");
});
// Constructor Functions
class Person {
    constructor(name, age) {
        this._name = name;
        this._age = age;
    }

    getName() {
        return this._name;
    }

    setName(value) {
        this._name = value;
    }

    getAge() {
        return this._age;
    }

    setAge(value) {
        this._age = value;
    }
}

var p1 = new Person("Manish", 0);
console.log(p1.getName());
console.log(p1.getAge());
p1.setName("Abhijeet");
p1.setAge(10);
console.log(p1.getName());
console.log(p1.getAge());

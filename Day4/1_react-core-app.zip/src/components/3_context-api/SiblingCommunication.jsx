import React, { Component } from 'react';
import { CounterContextProvider, CounterContext } from '../../context/CounterContext';

class Counter extends Component {
    static contextType = CounterContext;

    constructor(props) {
        super(props);
        this._inc = this._inc.bind(this);
        this._dec = this._dec.bind(this);
    }

    _inc(e) {
        var [count, setCount] = this.context;
        setCount(count + this.props.interval);
    }

    _dec(e) {
        var [count, setCount] = this.context;
        setCount(count - this.props.interval);
    }

    render() {
        return (
            <React.Fragment>
                <div className="text-center">
                    <h3 className="text-info">Counter Component</h3>
                </div>
                <div className="row d-flex justify-content-center">
                    <div className="col-sm-4">
                        <input type="text" className="form-control" value={this.context[0]} readOnly />
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info btn-block" onClick={this._inc}>+</button>
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info btn-block" onClick={this._dec}>-</button>
                    </div>
                </div>
            </React.Fragment>
        );
    }

    static get defaultProps() {
        return {
            interval: 1
        };
    }
}

class CounterSibling extends Component {
    static contextType = CounterContext;

    render() {
        return (
            <>
                <div className="text-center">
                    <h3 className="text-info">Counter Sibling Component</h3>
                    <h3>Current Count is: {this.context}</h3>
                </div>
            </>
        );
    }
}

const SiblingCommunicationUsingContext = () => {
    return (
        <div>
            <CounterContextProvider>
                <Counter />
                <hr />
                <CounterSibling />
            </CounterContextProvider>
        </div>
    );
};

export default SiblingCommunicationUsingContext;
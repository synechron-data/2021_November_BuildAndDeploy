import React, { Component, useState } from 'react';

class CounterUsingClass extends Component {
    constructor(props) {
        super(props);
        this.state = { count: 0 };
        this.inc = this.inc.bind(this);
        this.dec = this.dec.bind(this);
    }

    inc(e) {
        this.setState({ count: this.state.count + 1 });
    }

    dec(e) {
        this.setState({ count: this.state.count - 1 });
    }

    render() {
        return (
            <div>
                <h2 className="text-warning">Using Class Syntax</h2>
                <h2 className="text-info">Count: {this.state.count}</h2>
                <div className="row">
                    <div className="col-2">
                        <button className="btn btn-primary btn-block" onClick={this.inc}>+</button>
                    </div>
                    <div className="col-2">
                        <button className="btn btn-primary btn-block" onClick={this.dec}>-</button>
                    </div>
                </div>
            </div>
        );
    }
}

const CounterUsingFunction = () => {
    // const obj = useState();
    // console.log(obj);

    const [count, setCount] = useState(0);

    return (
        <div>
            <h2 className="text-warning">Using Function Syntax</h2>
            <h2 className="text-info">Count: {count}</h2>
            <div className="row">
                <div className="col-2">
                    <button className="btn btn-primary btn-block" onClick={() => setCount(count + 1)}>+</button>
                </div>
                <div className="col-2">
                    <button className="btn btn-primary btn-block" onClick={() => setCount(count - 1)}>-</button>
                </div>
            </div>
        </div>
    );
}

const HooksDemoComponent = () => {
    return (
        <div>
            <CounterUsingClass />
            <hr />
            <CounterUsingFunction />
        </div>
    );
};

export default HooksDemoComponent;
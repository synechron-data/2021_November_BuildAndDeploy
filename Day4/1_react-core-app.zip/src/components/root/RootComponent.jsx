/* eslint-disable */
import React from 'react';

import CalculatorAssignment from '../1_assignments/CalculatorAssignment';
import CounterAssignment from '../1_assignments/CounterAssignment';
import AjaxComponent from '../2_ajax/AjaxComponent';
import ContextAPIDemo from '../3_context-api/ContextAPIDemo';
import SiblingCommunicationUsingContext from '../3_context-api/SiblingCommunication';
import HooksDemoComponent from '../4_hooks/HooksDemoComponent';
import SiblingCommunicationUsingHooks from '../4_hooks/SiblingCommunicationUsingHooks';
import ErrorHandler from '../common/ErrorHandler';

const RootComponent = () => {
    return (
        <div className="container">
            <ErrorHandler>
                {/* <CalculatorAssignment /> */}
                {/* <CounterAssignment /> */}
                {/* <AjaxComponent /> */}
                {/* <ContextAPIDemo /> */}
                {/* <SiblingCommunicationUsingContext /> */}
                {/* <HooksDemoComponent /> */}
                <SiblingCommunicationUsingHooks />
            </ErrorHandler>
        </div>
    );
};

export default RootComponent;
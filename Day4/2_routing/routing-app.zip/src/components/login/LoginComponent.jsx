import React, { Component } from 'react';

class LoginComponent extends Component {
    render() {
        return (
            <div>
                <h1 className="text-primary">Login Component</h1>
            </div>
        );
    }
}

export default LoginComponent;
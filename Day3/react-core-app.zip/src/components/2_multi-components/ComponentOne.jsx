import React from 'react';

const ComponentOne = () => {
    return (
        <h2 className="text-success">
            Hello from Component One
        </h2>
    );
};

export default ComponentOne;
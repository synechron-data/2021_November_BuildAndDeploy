import React from 'react';
import PropTypes from 'prop-types';

// class DemoComponent extends React.Component {
//     render() {
//         return (
//             <div>
//                 <h2 className="text-info">Hello, {this.props.name}</h2>
//                 <h2 className="text-info">Age, {this.props.age}</h2>
//             </div>
//         );
//     }

//     static get defaultProps() {
//         return {
//             name: "Not Given",
//             age: 0
//         };
//     }
// }

class DemoComponent extends React.Component {
    render() {
        return (
            <div>
                <h2 className="text-info">Hello, {this.props.name}</h2>
                <h2 className="text-info">Age, {this.props.age}</h2>
            </div>
        );
    }

    static get displayName() {
        return "My Component";
    }

    static get propTypes() {
        return {
            name: PropTypes.string.isRequired,
            age: PropTypes.number.isRequired
        };
    }
}

const PropTypesComponent = () => {
    return (
        <div>
            <DemoComponent name={"Abhijeet"} age={10} />
            <DemoComponent />
            {/* <DemoComponent name={"Manish"}/> */}
        </div>
    );
};

export default PropTypesComponent;
import React, { Component } from 'react';

class Counter extends Component {
    render() {
        return (
            <React.Fragment>
                <div className="text-center">
                    <h3 className="text-info">Counter Component</h3>
                </div>
                <div className="row d-flex justify-content-center">
                    <div className="col-sm-4">
                        <input type="text" className="form-control" />
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info btn-block">+</button>
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info btn-block">-</button>
                    </div>
                    <div className="col-sm-2">
                        <button className="btn btn-info btn-block">Reset</button>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

class CounterAssignment extends Component {
    render() {
        return (
            <div>
                <Counter />
                <br />
                <Counter interval={10} />
            </div>
        );
    }
}

export default CounterAssignment;